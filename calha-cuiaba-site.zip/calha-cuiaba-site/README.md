# Calha Cuiabá

Aplicativo web para dimensionamento de calhas e condutores verticais de águas pluviais, conforme a ABNT NBR 10844, usando a curva IDF de Cuiabá (Castro, Silva e Silveira, UFMT, 2011).

- Coberturas: laje plana, uma água, duas águas, quatro águas, borboleta/água-furtada e curva
- Calhas: retangular, circular e triangular; aço, plástico e concreto
- Condutores verticais circulares ou retangulares
- Memorial de cálculo
- Funciona offline depois do primeiro acesso

**Desenvolvedor:** Eng. Civil e Sanitarista Raulmar Rodrigues de Freitas

Ferramenta de apoio. A responsabilidade técnica pelo projeto é do profissional habilitado.
